
void main()
{
    printf("Hello");
}