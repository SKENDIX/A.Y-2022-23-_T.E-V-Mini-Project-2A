const firebaseConfig = {
    apiKey: "AIzaSyAXQ-FUnKQ9CgIL18e_ESv9gyKoSJ4Irvs",
    authDomain: "infodiary-359618.firebaseapp.com",
    databaseURL: "https://infodiary-359618-default-rtdb.firebaseio.com",
    projectId: "infodiary-359618",
    storageBucket: "infodiary-359618.appspot.com",
    messagingSenderId: "853662707556",
    appId: "1:853662707556:web:bde46ceb18b5eba7939471"
};

firebase.initializeApp(firebaseConfig);

var infodb = firebase.database().ref('infodiary')

document.getElementById('form1').addEventListener('submit', submitform);

function submitform(e){
    e.preventDefault();

    var fullname = getElementByVal('fullname');
    var password = getElementByVal('password')
    var contact = getElementByVal('contact')
    var email = getElementByVal('email')
    var dob = getElementByVal('dob')
    saveMessages(fullname, password, contact, email, dob);

    window.location.replace("newindex (2).html");
}

const saveMessages = (fullname, password, contact, email, dob) => {
    var newBusiness = infodb.push();

    newBusiness.set({
        fullname : fullname,
        password : password,
        contact : contact,
        email : email,
        dob : dob
    })
};

const getElementByVal = (id) => {
    return document.getElementById(id).value;
};

//reset the form
document.getElementById("form1").reset();

