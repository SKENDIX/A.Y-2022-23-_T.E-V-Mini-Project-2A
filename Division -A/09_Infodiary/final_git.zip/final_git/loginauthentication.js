import { initializeApp } from "https://www.gstatic.com/firebasejs/9.9.4/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/9.9.4/firebase-auth.js";
import { getDatabase, set, ref, update } from "https://www.gstatic.com/firebasejs/9.9.4/firebase-database.js";




// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyDO56xLatfHbpauRKQ3SCs5aV2TYc76YI0",
    authDomain: "infodairy01.firebaseapp.com",
    projectId: "infodairy01",
    storageBucket: "infodairy01.appspot.com",
    messagingSenderId: "201778413635",
    appId: "1:201778413635:web:e6d83fef0b9b328243d4f6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const database = getDatabase(app);


login_b.addEventListener('click', (e) => {




    var email = document.getElementById('l_email').value;
    var password = document.getElementById('l_password').value;


    signInWithEmailAndPassword(auth, email, password)
        .then((userCredential) => {
            // Signed in 
            const user = userCredential.user;
            // ...
            var lgdate = new Date();


            update(ref(database, 'users/' + user.uid), {
                last_login: lgdate


            })
                .then(() => {
                    // Data saved successfully!
                    alert('User Logged In');
                    window.location.replace("./newmain.html");


                })
                .catch((error) => {
                    // The write failed...
                    alert(error);
                });

        })

        .catch((error) => {
            const errorCode = error.code;
            const errorMessage = error.message;
            alert(errorMessage)
        });

})