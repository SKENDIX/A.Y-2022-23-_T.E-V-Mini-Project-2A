<?php
$username = $_POST['fullname'];
$password = $_POST['password'];
$Contact = $_POST['Contact'];
$address = $_POST['address'];
$dob = $_POST['dob'];

if (!empty($username) || !empty($password) || !empty($Contact) || !empty($address) || !empty($dob)){
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "infodiary";

    //creating connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

    if (mysqli_connect_error()){
        die('Connect Error('.mysqli_connect_error().')'.mysqli_connect_error());
    } else {
        $SELECT = "SELECT Contact From registeredusers Where Contact = ? Limit 1";
        $INSERT = "INSERT Into registeredusers (FullName, Password, Contact, Address, DOB) values(?,?,?,?,?)";

        //prepare statement
        $stmt = $conn->prepare($SELECT);
        $stmt->bind_param("s", $Contact);
        $stmt->execute();
        $stmt->bind_result($Contact);
        $stmt->store_result();
        $rnum = $stmt->num_rows;

        if ($rnum==0) {
            $stmt->close();
            $stmt = $conn->prepare($INSERT);
            $stmt->bind_param("ssisi",$fullname, $password, $Contact, $address, $dob);
            $stmt->execute();
            echo "New record inserted successfully";
        } else {
            echo "Someone already registered using this contact number";
        }
        $stmt->close();
        $conn->close();
    }
} else{
    echo ("All fields are required!!");
    die();
}