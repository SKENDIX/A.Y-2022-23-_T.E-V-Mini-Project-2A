const firebaseConfiguration = {
    apiKey: "AIzaSyCBLL4VHHUEyYM8m5sw4BxJUgK6N2mGMYM",
    authDomain: "infodiary-form2.firebaseapp.com",
    databaseURL: "https://infodiary-form2-default-rtdb.firebaseio.com",
    projectId: "infodiary-form2",
    storageBucket: "infodiary-form2.appspot.com",
    messagingSenderId: "729090807664",
    appId: "1:729090807664:web:bb35d6baa229b447ca21b5"
  };

firebase.initializeApp(firebaseConfiguration);

var infodb = firebase.database().ref('InfoDiary-Form2')

document.getElementById('form2').addEventListener('submit', submitform);

function submitform(e){
    e.preventDefault();

    var address = getElementByVal('address');
    var pincode = getElementByVal('pincode')
    var city = getElementByVal('city')
    //var services = getElementByVal('services')

    // saveMessages(address, pincode, city);
    console.log(address, pincode, city)
}

// const saveAddress = (address, pincode, city) => {
//     var newBusiness = infodb.push();

//     newBusiness.set({
//         address : address,
//         pincode : pincode,
//         city : city,
//         // services : services
//     })
// };

const getElementByVal = (id) => {
     return document.getElementById(id).value;
};