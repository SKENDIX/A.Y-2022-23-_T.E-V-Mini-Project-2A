import smtplib #to send email
from email.mime.multipart import MIMEMultipart#sending email with file attachment
from email.mime.text import MIMEText #sending text emails
from tkinter import *


class email:
    def check():
        server_email = "qrcodegenerato@gmail.com"
        user_email = "sarthak4042@gmail.com"
        
        msg = MIMEMultipart('alternative')
        msg['Subject'] = "Link"
        msg['From'] = server_email
        msg['To'] = user_email
        text = "Hi!\nHow are you?\nHere is the link you wanted:\nhttp://www.python.org"
        html = f"""
        <html>
        <head>
        </head>
        <body>
        <H1 style="color:#00c2ff;text-align:center;"> QRCODEGENERATO </H1><br>
        
        <H4 style="text-align:left;"> Thanks for Registration,<br><span style="color:#00c2ff;">QRCODEGENERATO</span> Team </H4>
        </body>
        </html>
        """
        # moneybag image == <img src="https://i.ibb.co/wSkMR8W/et-img.png" alt="et-img" style="width:100px;height:100px;">

        part1 = MIMEText(text, 'plain')
        part2 = MIMEText(html, 'html')

        msg.attach(part1)
        msg.attach(part2)

        mail = smtplib.SMTP('smtp.gmail.com', 587)

        mail.ehlo()

        mail.starttls()

        mail.login('qrcodegenereto@gmail.com', 'posenapubcqkipmx')
        mail.sendmail(server_email, user_email, msg.as_string())
        mail.quit()
        print("email sent")
