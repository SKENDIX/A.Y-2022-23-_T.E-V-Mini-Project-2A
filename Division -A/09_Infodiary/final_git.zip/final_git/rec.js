import React from "react";
import PlacesAutocomplete from "react-places-autocomplete";
import scriptLoader from 'react-async-script-loader'

function App({ isScriptLoaded, isScriptLoadSucceed }){
    if (isScriptLoaded && isScriptLoadSucceed) {
        return<div>Google Maps Place Autocomplete</div>
    }
    else{
        return <div></div>
    }
}

export default scriptLoader([])(App);
