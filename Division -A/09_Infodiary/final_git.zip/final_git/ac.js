const firebaseConfig = {
    apiKey: "AIzaSyAAAXEgNS5jb3FXCYPrnnfrnMH7mc1O_1c",
    authDomain: "infodiary-ac-repairs.firebaseapp.com",
    databaseURL: "https://infodiary-ac-repairs-default-rtdb.firebaseio.com",
    projectId: "infodiary-ac-repairs",
    storageBucket: "infodiary-ac-repairs.appspot.com",
    messagingSenderId: "150627832239",
    appId: "1:150627832239:web:cc4eb74f293e90e5031f5a"
};

firebase.initializeApp(firebaseConfig);

var infodb = firebase.database().ref('InfoDiary-AC-Repairs')

document.getElementById('acrepairform').addEventListener('submit', submitform);

function submitform(e){
    e.preventDefault();

    var size = getElementByVal('size');
    var age = getElementByVal('old')
    var date = getElementByVal('date')
    var timeslots = getElementByVal('timeslots')
    var address = getElementByVal('address')
    
    saveMessages(size, age, date, timeslots, address);

    //window.location.replace("newmain.html");
}

const saveMessages = (size, age, date, timeslots, address) => {
    var newBusiness = infodb.push();

    newBusiness.set({
        ACSize : size,
        ACAge : age,
        Date : date,
        Timeslot : timeslots,
        address : address,
    })

    window.location.replace('booking.html')
};

const getElementByVal = (id) => {
    return document.getElementById(id).value;
};